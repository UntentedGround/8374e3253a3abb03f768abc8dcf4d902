<?php $__env->startSection('content'); ?>
	

<h1> Student List</h1>
<table id="mytable">
	<thead><tr><th>username</th><th>password</th></tr></thead>
	<tbody>
<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

        <tr><td> <?php echo $student->username; ?></td><td> <?php echo $student->password; ?></td></tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </tbody>
</table>

<script>
	$(document).ready(function(){
    alert("fuck you");
    $('#mytable').DataTable();

});

</script>
	

<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>