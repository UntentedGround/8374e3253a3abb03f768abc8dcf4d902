<?php $__env->startSection('content'); ?>
	

<h1> Student Profile</h1>

<p>

<b>username : </b> <?php echo $student->username; ?> <br>

<b>password : </b> <?php echo $student->password; ?> <br>

<b>email : </b> <?php echo $student->email; ?> <br>

<b>address : </b> <?php echo $student->address; ?> <br>

<b>district : </b> <?php echo $district->name; ?> <br>

<b>activated : </b> <?php echo ( $student->activated == 0) ? 'not activated' : 'activated'; ?> <br>


</p>


	

<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>