<?php $__env->startSection('content'); ?>
	
<h1> Coach Profile</h1>

<p>

<b>username : </b> <?php echo $coach->username; ?> <br>

<b>password : </b> <?php echo $coach->password; ?> <br>

<b>email : </b> <?php echo $coach->email; ?> <br>

<b>address : </b> <?php echo $coach->address; ?> <br>

<b>activated : </b> <?php echo ( $coach->activated == 0) ? 'not activated' : 'activated'; ?> <br>

</p>
<p>

<b>available district</b>

<br><li id = "HK" class="district">Hong Kong</li><br>
<br><li id = "KN" class="district">Kowloon</li><br>
<br><li id = "NT" class="district">New terriotry</li><br>

</p>

<script>
	$(document).ready(function(){


<?php $__currentLoopData = $all_districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	<?php if($district->region == 'HK'): ?>
			$('.district').filter($("#HK")).append('<br><input type="checkbox"> </input><b>{<?php echo $district->name; ?>}</b><br>');
	<?php elseif($district->region == 'KN'): ?>
			$('.district').filter($("#KN")).append('<br><input type="checkbox"> </input><b>{<?php echo $district->name; ?>}</b><br>');
	<?php else: ?> 
			$('.district').filter($("#NT")).append('<br><input type="checkbox"> </input><b>{<?php echo $district->name; ?>}</b><br>');

	<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    			


	});


</script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('masters.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>