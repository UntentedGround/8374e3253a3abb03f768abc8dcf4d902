<?php $__env->startSection('content'); ?>
	

<h1> Student List</h1>
<table id="mytable">
	<thead><tr><th>username</th><th>activated</th><th>action</th></tr></thead>
	<tbody>
<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

        <tr><td> <?php echo $student->username; ?></td><td> <?php echo ($student->activated == 0) ? 'not activated':'activated'; ?></td>
	<td><a href=student/<?php echo $student->student_id; ?>>view</a> <a onclick="enable_student(<?php echo $student->student_id; ?>,'<?php echo $student->username; ?>',<?php echo $student->activated; ?>)">enable/disable</a> <a onclick="delete_student(<?php echo $student->student_id; ?>,'<?php echo $student->username; ?>')">delete</a></td></tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </tbody>
</table>

<script>
	$(document).ready(function(){
    $('#mytable').DataTable();


});

	function delete_student(student_id,username){

		if (confirm("are you sure deleting student [" + username + "] ?") == true){
		
			window.location.href = "asdfsd";	
		}
	}

	function enable_student(student_id,username, activated){

		if (activated == 1)

		{
			alert('activated = 1');
			if (confirm("are you sure to disable student [" + username + "] ?") == true){
		
				window.location.href = "disable_student" ;
			}	
		}

		else

		{
			alert('activated = 1');

			if (confirm("are you sure to enable student [" + username + "] ?") == true){
		
				window.location.href = "enable_student" ;
			}
		}
		

		



	}


</script>
	

<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>