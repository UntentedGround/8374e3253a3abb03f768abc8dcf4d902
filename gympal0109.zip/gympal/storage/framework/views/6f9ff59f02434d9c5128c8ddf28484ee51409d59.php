<?php $__env->startSection('content'); ?>
    <!--/* JQuery was added in the master*/-->
    <script src = "<?php echo e(URL::to('formValidateLib/jquery.validate.js')); ?>"></script>
    <script src = "<?php echo e(URL::to('formValidateLib/additional-methods.js')); ?>"></script>
    <script src = "<?php echo e(URL::to('formValidateLib/localization/messages_zh_TW.min.js')); ?>"></script>
    <link rel="stylesheet" href=" <?php echo e(URL::to('formValidateLib/animate.min.css')); ?> ">
    <style>
        label.error{
            color: #f33;
            padding: 0;
            margin: 2px 0 0 0;
            font-size: 0.7em;
        }
        .defaultHidden{
            display:none;
        }
    </style>

    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header"> 學生登記 </h1>
        </div>
    </div>

    <!--
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading"> Some Title Here </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <form id ="" role="form">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    -->

    <!-- BasicInformation Form -->
    <div class="row" id = "BasicInformationFormRow">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading"> 基本資料 </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <form class = "" id = "BasicInformationForm" role="form" action="studentRegister" method="post">
                                <p><b>個人資料</b></p>
                                <div class="form-group">
                                    登入電郵<input class = "must form-control" type="text" name ="loginEmail"/><br>
                                    登入密碼<input class = "must form-control" type="password" id="loginPassword" name ="loginPassword"><br>
                                    確認密碼<input class = "must form-control" type="password" id="confirmPassword" name ="confirmPassword"><br>
                                    顯示名稱<input class = "must form-control" type="text" name ="username"><br>
                                    英文姓名<input class = "must form-control" type="text" name ="engName"><br>
                                    中文姓名<input class = "must form-control" type="text" name ="chinName"><br>
                                    身份證號碼<input class = "must form-control" type="text" name ="HKID"><br>
                                </div>
                                <div class="form-group">
                                    住宅地址<input class = "must form-control" type="text" name ="address"><br>
                                    <!-- Should use select here -->
                                    住宅區域
                                    <select class="must form-control" name="district">
                                        <option value ="default">--請選擇--</option>
                                        <option value="" disabled><p><b>---香港島---</b></p></option>
                                        <?php $__currentLoopData = $hkDistricts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hkDistrict): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <option value="<?php echo $hkDistrict->district_id; ?>"/> <?php echo $hkDistrict->name_chin; ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        <option value="" disabled><p><b>---九龍區---</b></p></option>
                                        <?php $__currentLoopData = $knDistricts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $knDistrict): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <option value="<?php echo $knDistrict->district_id; ?>"/> <?php echo $knDistrict->name_chin; ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        <option value="" disabled><p><b>---新界區---</b></p></option>
                                        <?php $__currentLoopData = $ntDistricts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ntDistrict): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <option value="<?php echo $ntDistrict->district_id; ?>"/> <?php echo $ntDistrict->name_chin; ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        <!--<input type="checkbox" name="area[]" value="1"/> 中半山，薄扶林 <br>-->
                                    </select>
                                </div>
                                <div class="form-group">
                                    電話號碼<input class = "must form-control" type="text" name ="teleno"><br>
                                    出生年份<input class = "must form-control" type="text" name ="birthday"><br>
                                </div>
                                <div class="form-group">
                                    性別<br />
                                    <input class ="must" type="radio" name = "gender" value="male"/>男 <input class ="must" type="radio" name = "gender" value="female"/>女 <span id="genderError"> </span><br />
                                </div>
                                <div class="form-group">
                                    <input type ="submit" value ="完成登記"/>
                                </div>
                                <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>

        /*
         .serialize().replace(/%5B%5D/g, '[]')
         The meaning of this is to send serialize form data, with array
         */
        $('#BasicInformationForm').on('submit',function(e){
            e.preventDefault();
            console.log("hi");
            $.ajax({
                method     :"POST",
                url: $('#BasicInformationForm').attr( 'action' ),
                data     : $('#BasicInformationForm').serialize().replace(/%5B%5D/g, '[]'),
                success  : function(data) {
                    console.log("success ajax request!");
                    console.log(data);
                }
            });

        });



        $('#BasicInformationForm').on('change',function(){
            /*
            if($("#otherCField").is(":checked")){
                $("#extendCategory").show();
            }
            else{
                $("#extendCategory").hide();
            }

            if($('input[name=provideClassroom]:checked').val() === "yes")
                $("#classroomOption").show();
            else{
                $("#classroomOption").hide();
            }
            */
        });

        $.fn.extend({
            animateCss: function (animationName, cb) {
                var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
                this.addClass('animated ' + animationName).one(animationEnd, function() {
                    $(this).removeClass('animated ' + animationName);
                    if(cb){
                        cb();
                    }
                });
            }
        });

        $.validator.addMethod("mRequired", $.validator.methods.required,
            "必須填寫");

        $.validator.addMethod("regex",
            function(value, element, regexp) {
                var re = new RegExp(regexp);
                return this.optional(element) || re.test(value);}
            ,"格式錯誤");

        $.validator.addMethod("valueNotEquals", function(value, element, arg){
                return arg != value;}
            ,"Value must not equal arg.");

        jQuery.validator.addClassRules({
            must:{
                mRequired : true,
            },
        });


        $(document).ready(function(){

            // Basic  Form Validation
            $("#BasicInformationForm").validate({
                rules : {
                    'birthday':{
                        regex:"^(?=.*?[0-9]).{4,4}$",
                    },
                    'loginEmail':{
                        email:true,
                    },
                    'loginPassword':{
                        regex: "^(?=.*[A-Za-z])(?=.*?[0-9]).{8,}$"
                    },
                    confirmPassword:{
                        equalTo:"#loginPassword"
                    },
                    engName:{
                        regex:"^[a-zA-Z ]*$"
                    },
                    chinName:{
                        regex:"^(?=.*[\u4e00-\u9eff]).{1,20}$"
                    },
                    teleno:{
                        regex:"^(?=.*?[0-9]).{8,}$"
                    }
                },
                messages:{
                    'birthday':{
                        regex:"請輸入有效出生年份",
                    },
                    'loginEmail':{
                        email:"請輸入有效的電子郵件"
                    },
                    loginPassword:{
                        regex:"密碼至少8位由英文字母及數字組合組成"
                    },
                    confirmPassword:{
                        equalTo:"與已填寫密碼不相同"
                    },
                    engName:{
                        regex:"請填寫有效英文名稱"
                    },
                    chinName:{
                        regex:"請填寫有效中文名稱"
                    },
                    HKID:{
                        mRequired:"請輸入身份證號碼"
                    },
                    address:{
                        mRequired:"請輸入地址"
                    },
                    district:{
                        mRequired:"請選擇有效地區"
                    },
                    teleno:{
                        regex:"請填寫有效電話號碼"
                    },
                    gender:{
                        mRequired:"必須選擇"
                    }

                },
                errorPlacement: function(error, element) {
                    if((element.attr('name') === 'category[]')){
                        error.appendTo("#categoryError");
                    }
                    else if ((element.attr('name') === 'extendCategory')){
                        error.insertAfter(element);
                    }
                    else if ((element.attr('name') === 'gender')){
                        error.appendTo(genderError)
                    }
                    else if ((element.attr('name') === 'groupClass')){
                        error.appendTo(groupClassError)
                    }
                    else if ((element.attr('name') === 'provideClassroom')){
                        error.appendTo(provideClassroomError)
                    }
                    else {
                        error.insertAfter(element);
                    }
                },
                submitHandler: function (form) {
                    $('#BasicInformationFormRow').animateCss('slideOutRight', function(){
                            $('#BasicInformationFormRow').hide();
                            $('#BasicInformationForm').hide();
                        }
                    );

                    return false
                }
            });

        });

    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('masters.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>