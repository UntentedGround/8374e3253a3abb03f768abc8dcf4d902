<?php $__env->startSection('content'); ?>

<h1> Coach List</h1>
<table id="mytable">
	<thead><tr><th>username</th><th>activated</th><th>action</th></tr></thead>
	<tbody>
<?php $__currentLoopData = $coachs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coach): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

        <tr><td> <?php echo $coach->username; ?></td><td> <?php echo ($coach->activated == 0) ? 'not activated':'activated'; ?></td>
	<td><a href=coach/<?php echo $coach->coach_id; ?>>view</a> <a onclick="enable_coach(<?php echo $coach->coach_id; ?>,'<?php echo $coach->username; ?>',<?php echo $coach->activated; ?>)">enable/disable</a> <a onclick="delete_coach(<?php echo $coach->coach_id; ?>,'<?php echo $coach->username; ?>')">delete</a></td></tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </tbody>
</table>

<script>
	$(document).ready(function(){
    $('#mytable').DataTable();


});

	function delete_coach(coach_id,username){

		if (confirm("are you sure deleting coach [" + username + "] ?") == true){
		
			window.location.href = "deletecoach";	
		}
	}

	function enable_coach(coach_id,username, activated){

		if (activated == 1)

		{
			alert('activated = 1');
			if (confirm("are you sure to disable coach [" + username + "] ?") == true){
		
				window.location.href = "disable_coach" ;
			}	
		}

		else

		{
			alert('activated = 1');

			if (confirm("are you sure to enable coach [" + username + "] ?") == true){
		
				window.location.href = "enable_coach" ;
			}
		}
		

		



	}


</script>
	

<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>