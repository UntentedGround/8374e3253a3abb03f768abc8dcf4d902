<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/studentApply', [
    'uses' => 'StudentApplyController@prepareForm',
    'as' => 'studentApply'
]);

Route::get('/coachApply', [
    'uses' => 'CoachApplyController@prepareForm',
    'as' => 'coachApply'
]);

Route::get('/student', [
	'uses' => 'AdminController@list_student',
	'as' => 'list_student'
]);

Route::get('/coach', [
	'uses' => 'AdminController@list_coach',
	'as' => 'list_coach'
]);

Route::get('/student/{student_id}', [
	'uses' => 'AdminController@view_student',
	'as' => 'view_student'
]);

Route::get('/coach/{coach_id}', [
	'uses' => 'AdminController@view_coach',
	'as' => 'view_coach'
]);

Route::post('/coachRegister','CoachApplyController@store');

Route::post('/studentRegister','StudentApplyController@store');

