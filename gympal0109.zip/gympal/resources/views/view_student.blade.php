@extends('masters.master')

@section('content')
	

<h1> Student Profile</h1>

<p>

<b>username : </b> {!!$student->username !!} <br>

<b>password : </b> {!!$student->password !!} <br>

<b>email : </b> {!!$student->email !!} <br>

<b>address : </b> {!!$student->address !!} <br>

<b>district : </b> {!! $district->name !!} <br>

<b>activated : </b> {!! ( $student->activated == 0) ? 'not activated' : 'activated' !!} <br>


</p>


	

@endsection
