@extends('masters.master')

@section('content')
	

<h1> Student List</h1>
<table id="mytable">
	<thead><tr><th>username</th><th>activated</th><th>action</th></tr></thead>
	<tbody>
@foreach ($students as $student)

        <tr><td> {!!$student->username !!}</td><td> {!! ($student->activated == 0) ? 'not activated':'activated' !!}</td>
	<td><a href=student/{!! $student->student_id!!}>view</a> <a onclick="enable_student({!! $student->student_id!!},'{!! $student->username!!}',{!! $student->activated!!})">enable/disable</a> <a onclick="delete_student({!! $student->student_id!!},'{!! $student->username!!}')">delete</a></td></tr>

@endforeach
        </tbody>
</table>

<script>
	$(document).ready(function(){
    $('#mytable').DataTable();


});

	function delete_student(student_id,username){

		if (confirm("are you sure deleting student [" + username + "] ?") == true){
		
			window.location.href = "asdfsd";	
		}
	}

	function enable_student(student_id,username, activated){

		if (activated == 1)

		{
			alert('activated = 1');
			if (confirm("are you sure to disable student [" + username + "] ?") == true){
		
				window.location.href = "disable_student" ;
			}	
		}

		else

		{
			alert('activated = 1');

			if (confirm("are you sure to enable student [" + username + "] ?") == true){
		
				window.location.href = "enable_student" ;
			}
		}
		

		



	}


</script>
	

@endsection
