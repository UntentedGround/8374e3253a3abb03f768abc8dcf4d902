@extends('masters.master')

@section('content')
    <!--/* JQuery was added in the master*/-->
    <script src = "{{ URL::to('formValidateLib/jquery.validate.js') }}"></script>
    <script src = "{{ URL::to('formValidateLib/additional-methods.js') }}"></script>
    <script src = "{{ URL::to('formValidateLib/localization/messages_zh_TW.min.js') }}"></script>
    <link rel="stylesheet" href=" {{ URL::to('formValidateLib/animate.min.css') }} ">
    <style>
        label.error{
            color: #f33;
            padding: 0;
            margin: 2px 0 0 0;
            font-size: 0.7em;
        }
        .defaultHidden{
            display:none;
        }
    </style>

    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header"> 教練登記 </h1>
        </div>
    </div>

    <!--
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading"> Some Title Here </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <form id ="" role="form">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    -->

    <!-- Declaration Form -->
    <div class="row" id ="declarationFormRow">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading"> 聲明 </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <form id ="declarationForm" role="form">
                                <div class="form-group">
                                    <textarea class="form-control" disabled="disabled">條款</textarea>
                                </div>
                                <div class="form-group">
                                    <input type="checkbox" name="agreeDeclarationBox" value="check"/> 本人已參閱以上導師條款，並同意GYMAPAL的私隱政策、使用條款及導師收費；本人保證填妥丟資料正確無誤。<br>
                                    <labal class = "error" id = "dcError"></labal>
                                </div>
                                <div class="form-group">
                                    <input type="submit" name="" value="同意" />
                                </div>
                                <input type="hidden" name="_token" value="{{ Session::token() }}">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- BasicInformation Form -->
    <div class="row defaultHidden" id = "BasicInformationFormRow">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading"> 基本資料 </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <form class = "defaultHidden" id = "BasicInformationForm" role="form">
                                <div class="form-group">
                                    <p><b>請選擇教練登記類別 （可選擇多於一項）</b></p>
                                    <!--
                                    /*Example of original checkbox*/
                                    <input type="checkbox" name="category[]" value="fitness"/> 健身 <br>
                                    -->
                                    @foreach ($categories as $category)
                                        <input type="checkbox" name="category[]" value="{!!$category->name!!}"/> {!! $category->name_chin !!} <br>
                                    @endforeach

                                    <input type="checkbox" id="otherCField" name="category[]" value="otherCategory"/> 其它 <input class="defaultHidden form-control" type="text" id = "extendCategory" name ="extendCategory"><br>
                                    <div id="categoryError">
                                    </div>
                                </div>
                                <p><b>個人資料</b></p>
                                <div class="form-group">
                                    登入電郵<input class = "must form-control" type="text" name ="loginEmail"/><br>
                                    登入密碼<input class = "must form-control" type="password" id="loginPassword" name ="loginPassword"><br>
                                    確認密碼<input class = "must form-control" type="password" id="confirmPassword" name ="confirmPassword"><br>
                                    顯示名稱<input class = "must form-control" type="text" name ="username"><br>
                                    英文姓名<input class = "must form-control" type="text" name ="engName"><br>
                                    中文姓名<input class = "must form-control" type="text" name ="chinName"><br>
                                    身份證號碼<input class = "must form-control" type="text" name ="HKID"><br>
                                    住宅地址<input class = "must form-control" type="text" name ="address"><br>
<!--                                    住宅區域<input class = "must form-control" type="text" name ="area"><br>-->
                                    電話號碼<input class = "must form-control" type="text" name ="teleno"><br>
                                    出生年份<input class = "must form-control" type="text" name ="birthday"><br>
                                </div>
                                <div class="form-group">
                                    性別<br />
                                    <input class ="must" type="radio" name = "gender" value="male"/>男 <input class ="must" type="radio" name = "gender" value="female"/>女 <span id="genderError"> </span><br />
                                </div>
                                <div class="form-group">
                                    能否提供上課場地<br />
                                    <input class="must" type="radio" id="canProvideClassroom" name ="provideClassroom" value="yes"> 可以 <input class="must" type="radio" name ="provideClassroom" value="no"> 不可以 <span id="provideClassroomError"> </span><br>
                                    <div id="classroomOption" class="defaultHidden" >
                                        地址<input class="form-control" id="classroomAddress" type="text" name ="classroomAddress"><br>
                                    </div>
                                </div>
                                <div class="form-group">
                                    現時有安排小組課堂<br />
                                    <input class ="must" type="radio" name ="groupClass" value="yes"> 有 <input class ="must" type="radio" name ="groupClass" value="no"> 沒有 <span id="groupClassError"> </span><br>
                                </div>
                                <div class="form-group">
                                    <input type ="submit" value ="下一步"/>
                                </div>
                                <input type="hidden" name="_token" value="{{ Session::token() }}">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Teaching Info Form -->
    <div class="row defaultHidden" id = "teachingInfoFormRow">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading"> 授課地區 </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <form class = "defaultHidden" id = "teachingInfoForm" role="form">
                                <div class="form-group">
                                    <p><b>授課地區 （可選擇多於一項）</b></p>
                                </div>
                                <div class="form-group">
                                    <p><b>香港島</b></p>
                                    <!--<input type="checkbox" name="area[]" value="1"/> 中半山，薄扶林 <br>-->
                                    @foreach ($hkDistricts as $hkDistrict)
                                        <input type="checkbox" name="area[]" value="{!!$hkDistrict->district_id!!}"/> {!! $hkDistrict->name_chin !!} <br>
                                    @endforeach

                                    <!-- 	<div id="hkIslandError"></div> -->
                                </div>
                                <div class="form-group">
                                    <p><b>九龍區</b></p>
                                    @foreach ($knDistricts as $knDistrict)
                                        <input type="checkbox" name="area[]" value="{!!$knDistrict->district_id!!}"/> {!! $knDistrict->name_chin !!} <br>
                                    @endforeach
                                    <!-- 				<div id="kowloonError"></div> -->
                                </div>
                                <div class="form-group">
                                    <p><b>新界區</b></p>
                                    @foreach ($ntDistricts as $ntDistrict)
                                        <input type="checkbox" name="area[]" value="{!!$ntDistrict->district_id!!}"/> {!! $ntDistrict->name_chin !!} <br>
                                    @endforeach
                                </div>
                                <div id="areaError"></div>

                                <div class="form-group">
                                    <p><b>授課時間</b></p>
                                    <table id="classTimetable">
                                        <tr>
                                            <th></th>
                                            <th>星期一</th>
                                            <th>星期二</th>
                                            <th>星期三</th>
                                            <th>星期四</th>
                                            <th>星期五</th>
                                            <th>星期六</th>
                                            <th>星期日</th>
                                        </tr>
                                        <tr>
                                            <td>06:00-09:00&nbsp;</td>
                                            <td><input type="checkbox" name="monday[]" value="1"/></td>
                                            <td><input type="checkbox" name="tuesday[]" value="1"/></td>
                                            <td><input type="checkbox" name="wednesday[]" value="1"/></td>
                                            <td><input type="checkbox" name="thursday[]" value="1"/></td>
                                            <td><input type="checkbox" name="friday[]" value="1"/></td>
                                            <td><input type="checkbox" name="saturday[]" value="1"/></td>
                                            <td><input type="checkbox" name="sunday[]" value="1"/></td>
                                        </tr>
                                        <tr>
                                            <td>09:00-12:00&nbsp;</td>
                                            <td><input type="checkbox" name="monday[]" value="2"/></td>
                                            <td><input type="checkbox" name="tuesday[]" value="2"/></td>
                                            <td><input type="checkbox" name="wednesday[]" value="2"/></td>
                                            <td><input type="checkbox" name="thursday[]" value="2"/></td>
                                            <td><input type="checkbox" name="friday[]" value="2"/></td>
                                            <td><input type="checkbox" name="saturday[]" value="2"/></td>
                                            <td><input type="checkbox" name="sunday[]" value="2"/></td>
                                        </tr>
                                        <tr>
                                            <td>12:00-15:00&nbsp;</td>
                                            <td><input type="checkbox" name="monday[]" value="3"/></td>
                                            <td><input type="checkbox" name="tuesday[]" value="3"/></td>
                                            <td><input type="checkbox" name="wednesday[]" value="3"/></td>
                                            <td><input type="checkbox" name="thursday[]" value="3"/></td>
                                            <td><input type="checkbox" name="friday[]" value="3"/></td>
                                            <td><input type="checkbox" name="saturday[]" value="3"/></td>
                                            <td><input type="checkbox" name="sunday[]" value="3"/></td>
                                        </tr>
                                        <tr>
                                            <td>15:00-18:00&nbsp;</td>
                                            <td><input type="checkbox" name="monday[]" value="4"/></td>
                                            <td><input type="checkbox" name="tuesday[]" value="4"/></td>
                                            <td><input type="checkbox" name="wednesday[]" value="4"/></td>
                                            <td><input type="checkbox" name="thursday[]" value="4"/></td>
                                            <td><input type="checkbox" name="friday[]" value="4"/></td>
                                            <td><input type="checkbox" name="saturday[]" value="4"/></td>
                                            <td><input type="checkbox" name="sunday[]" value="4"/></td>
                                        </tr>
                                        <tr>
                                            <td>18:00-21:00&nbsp;</td>
                                            <td><input type="checkbox" name="monday[]" value="5"/></td>
                                            <td><input type="checkbox" name="tuesday[]" value="5"/></td>
                                            <td><input type="checkbox" name="wednesday[]" value="5"/></td>
                                            <td><input type="checkbox" name="thursday[]" value="5"/></td>
                                            <td><input type="checkbox" name="friday[]" value="5"/></td>
                                            <td><input type="checkbox" name="saturday[]" value="5"/></td>
                                            <td><input type="checkbox" name="sunday[]" value="5"/></td>
                                        </tr>
                                        <tr>
                                            <td>21:00-00:00&nbsp;</td>
                                            <td><input type="checkbox" name="monday[]" value="6"/></td>
                                            <td><input type="checkbox" name="tuesday[]" value="6"/></td>
                                            <td><input type="checkbox" name="wednesday[]" value="6"/></td>
                                            <td><input type="checkbox" name="thursday[]" value="6"/></td>
                                            <td><input type="checkbox" name="friday[]" value="6"/></td>
                                            <td><input type="checkbox" name="saturday[]" value="6"/></td>
                                            <td><input type="checkbox" name="sunday[]" value="6"/></td>
                                        </tr>
                                        <tr>
                                            <td>全日&nbsp;</td>
                                            <td><input type="checkbox" name="monday[]" value="7"/></td>
                                            <td><input type="checkbox" name="tuesday[]" value="7"/></td>
                                            <td><input type="checkbox" name="wednesday[]" value="7"/></td>
                                            <td><input type="checkbox" name="thursday[]" value="7"/></td>
                                            <td><input type="checkbox" name="friday[]" value="7"/></td>
                                            <td><input type="checkbox" name="saturday[]" value="7"/></td>
                                            <td><input type="checkbox" name="sunday[]" value="7"/></td>
                                        </tr>

                                    </table>
                                </div>
                                <div class="form-group">
                                    <input type ="submit" value ="下一步"/>
                                </div>
                                <input type="hidden" name="_token" value="{{ Session::token() }}">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Coach CV Form -->
    <div class="row defaultHidden" id = "coachCVFormRow">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading"> 教練履歷 </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <form class="defaultHidden" id = "coachCVForm" action="coachRegister" method="post" role="form">
<!--                            <form class="defaultHidden" id = "coachCVForm" role="form">-->

                                <div class="form-group">
                                    <p><b>個人簡介</b></p>
                                    <p><b>請上傳相片，可以更容易找到成功個案及有機會登上Top10教練。</b></p>
                                    相片上傳<input type="file" name="coachPhotos" id="coachPhotos" accept="image/*" /><br>
                                    Facebook<input class="form-control" type="text" name="coachFacebook"><br>
                                    Instagram<input class="form-control" type="text" name="coachInstagram"><br>
                                    自我介紹(請詳細講述教學經驗,過往履歷及相關資格)<br>
                                    <textarea class = "must form-control" rows="10" cols="80"  name="coachIntroduction"></textarea> <br>
                                </div>

                                <div class="form-group">
                                    <b>教學經驗</b><br>
                                    教學年資
                                    <input class="must" type="text" name="experienceSelection" id="experienceSelection"/><br>
<!--    
                                    <select name="experienceSelection" id="experienceSelection">
                                        <option value="default">--請選擇--</option>
                                        <option value="1">沒有教學經驗</option>
                                        <option value="1">1年以下</option>
                                        <option value="2">1－5年</option>
                                        <option value="3">5年以上</option>
                                    </select> <br>
-->
                                </div>
                                <div class="form-group">
                                    現時職業
                                    <input class="must" type="text" name="occupationSelection" id="occupationSelection"/><br>

<!--
                                    <select name = "occupationSelection" id="occupationSelection">
                                        <option value="default">--請選擇--</option>
                                        <option value="volvo">教練</option>
                                        <option value="saab">學生</option>
                                        <option value="mercedes">無任何職業</option>
                                    </select><br>
-->
                                </div>

                                <div class="form-group">
                                    <p><b>履歷資料（請上傳有關教練資格證明，可以更有效找到成功個案，有機會登上Top10教練，如未能提供有關證明，如能成功申請個案，請在第一堂時侯帶同有關資格證明副本）</b></p>
                                    <input type="file" name="coachCV" id="coachCV" accept="application/mswordapplication/pdf" /><br>
                                    <input type="file" name="coachCV2" id="coachCV2" accept="application/msword,application/pdf" /><br>
                                    <input type="file" name="coachCV3" id="coachCV3" accept="application/msword,application/pdf" /><br>
                                </div>

                                <div class="form-group">
                                    <b>教練時薪</b><br>
                                    最低教練時薪（小時）<input class = "must form-control" type="text" name="minHourlyWage"><br>
                                    理想教練時薪（小時）<input class = "must form-control" type="text" name="idealHourlyWage"><br>
                                </div>

                                <div class="form-group">
                                    <input type ="submit" value ="完成登記"/>
                                </div>
                                <input type="hidden" name="_token" value="{{ Session::token() }}">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <script>

        /*
        .serialize().replace(/%5B%5D/g, '[]')
        The meaning of this is to send serialize form data, with array
        */
        $('#coachCVForm').on('submit',function(e){
            e.preventDefault();
            console.log("HI");
            $.ajax({
                method     :"POST",
                url: $('#coachCVForm').attr( 'action' ),
                data     : $('#BasicInformationForm').serialize().replace(/%5B%5D/g, '[]')+"&"+$("#teachingInfoForm").serialize().replace(/%5B%5D/g, '[]')+"&"+$(this).serialize().replace(/%5B%5D/g, '[]'),
                success  : function(data) {
                    console.log("success ajax request!");
                    console.log(data);
                }
             });

        });



        $('#BasicInformationForm').on('change',function(){
            
            if($("#otherCField").is(":checked")){
                 $("#extendCategory").show();
            }
            else{
                 $("#extendCategory").hide();
            }
            
            if($('input[name=provideClassroom]:checked').val() === "yes")
                $("#classroomOption").show();
            else{
                $("#classroomOption").hide();
            }
        });

        $.fn.extend({
            animateCss: function (animationName, cb) {
                var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
                this.addClass('animated ' + animationName).one(animationEnd, function() {
                    $(this).removeClass('animated ' + animationName);
                    if(cb){
                        cb();
                    }
                });
            }
        });

        $.validator.addMethod("mRequired", $.validator.methods.required,
            "必須填寫");

        $.validator.addMethod("regex",
            function(value, element, regexp) {
                var re = new RegExp(regexp);
                return this.optional(element) || re.test(value);}
            ,"格式錯誤");

        $.validator.addMethod("valueNotEquals", function(value, element, arg){
                return arg != value;}
            ,"Value must not equal arg.");

        jQuery.validator.addClassRules({
            must:{
                mRequired : true,
            },
        });


        $(document).ready(function(){


            // Declaration Form Validation
            $("#declarationForm").validate({
                rules : {
                    'agreeDeclarationBox':{
                        required: true,
                    }
                },
                messages:{
                    'agreeDeclarationBox':{
                        required: "Please check this Box.",
                    }
                },
                errorPlacement: function(error, element) {
                    if((element.attr('name') === 'agreeDeclarationBox')){
                        error.insertAfter("#dcError");
                    }
                },
                submitHandler: function (form) {
                    $('#declarationFormRow').animateCss('slideOutRight', function(){
                            $('#declarationFormRow').hide();
                            $('#declarationForm').hide();
                            $('#BasicInformationFormRow').show();
                            $('#BasicInformationForm').show();
                            $('#BasicInformationFormRow').animateCss('slideInLeft');
                            $('#BasicInformationForm').animateCss('slideInLeft');
                        }
                    );

                    return false
                }
            });
            // Basic  Form Validation
            $("#BasicInformationForm").validate({
                rules : {
                    'category[]':{
                        required: true,
                    },
                    'extendCategory':{
                        required:"input:checkbox[id=otherCField]:checked"
                    },
                    'birthday':{
                        regex:"^(?=.*?[0-9]).{4,4}$",
                        
                    },
                    'loginEmail':{
                        email:true,
                    },
                    'loginPassword':{
                        regex: "^(?=.*[A-Za-z])(?=.*?[0-9]).{8,}$"
                    },
                    confirmPassword:{
                        equalTo:"#loginPassword"
                    },
                    engName:{
                        regex:"^[a-zA-Z ]*$"
                    },
                    chinName:{
                        regex:"^(?=.*[\u4e00-\u9eff]).{1,20}$"
                    },
                    teleno:{
                        regex:"^(?=.*?[0-9]).{8,}$"
                    },
                    classroomAddress:{
                        required:"input:radio[id=canProvideClassroom]:checked",
                    }

                },
                messages:{
                    'category[]':{
                        required: "必須選擇一項或以上",
                    },
                    'extendCategory':{
                        required:"請填寫有關資料"
                    },
                     'birthday':{
                        regex:"請輸入有效出生年份",
                       
                    },
                    'loginEmail':{
                        email:"請輸入有效的電子郵件"
                    },
                    loginPassword:{
                        regex:"密碼至少8位由英文字母及數字組合組成"
                    },
                    confirmPassword:{
                        equalTo:"與已填寫密碼不相同"
                    },
                    engName:{
                        regex:"請填寫有效英文名稱"
                    },
                    chinName:{
                        regex:"請填寫有效中文名稱"
                    },
                    teleno:{
                        regex:"請填寫有效電話號碼"
                    },
                    gender:{
                        mRequired:"必須選擇"
                    },
                    groupClass:{
                        mRequired:"必須選擇"
                    },
                    provideClassroom:{
                        mRequired:"必須選擇"
                    },
                    classroomAddress:{
                        requried:"必須填寫"
                    }

                },
                errorPlacement: function(error, element) {
                    if((element.attr('name') === 'category[]')){
                        error.appendTo("#categoryError");
                    }
                    else if ((element.attr('name') === 'extendCategory')){
                        error.insertAfter(element);
                    }
                    else if ((element.attr('name') === 'gender')){
                        error.appendTo(genderError)
                    }
                    else if ((element.attr('name') === 'groupClass')){
                        error.appendTo(groupClassError)
                    }
                    else if ((element.attr('name') === 'provideClassroom')){
                        error.appendTo(provideClassroomError)
                    }
                    else {
                        error.insertAfter(element);
                    }
                },
                submitHandler: function (form) {
                    $('#BasicInformationFormRow').animateCss('slideOutRight', function(){
                            $('#BasicInformationFormRow').hide();
                            $('#BasicInformationForm').hide();
                            $('#teachingInfoFormRow').show();
                            $('#teachingInfoForm').show();
                            $('#teachingInfoFormRow').animateCss('slideInLeft');
                            $('#teachingInfoForm').animateCss('slideInLeft');
                        }
                    );

                    return false
                }
            });

            //TeachingInfoForm
            $("#teachingInfoForm").validate({
                rules:{
                    "area[]":{
                        required:true
                    },
                },
                messages: {
                    "area[]":{
                        required:"必須從三個地區中選擇其中一項或以上"
                    },
                },
                errorPlacement: function(error, element) {
                    if((element.attr('name') === 'area[]')){
                        error.appendTo("#areaError");
                    }
                    else{
                        error.insertAfter(element);
                    }
                },
                submitHandler: function (form) {
                    $('#teachingInfoFormRow').animateCss('slideOutRight', function(){
                            $('#teachingInfoFormRow').hide();
                            $('#teachingInfoForm').hide();
                            $('#coachCVFormRow').show();
                            $('#coachCVForm').show();
                            $('#coachCVFormRow').animateCss('slideInLeft');
                            $('#coachCVForm').animateCss('slideInLeft');
                        }
                    );
                    return false
                }
            });
            $("#coachCVForm").validate({
                rules:{
                    experienceSelection:{
//                        valueNotEquals:"default"
                        regex:"^(?=.*?[0-9]).{1,}$"
                        
                    },
                    occupationSelection:{
//                        valueNotEquals:"default"
                        regex:"^(?=.*[0-9A-Za-z\u4e00-\u9eff]).{1,20}$"
                        
                    },
                    minHourlyWage:{
                        regex:"^[0-9]*$"
                    },
                    idealHourlyWage:{
                        regex:"^[0-9]*$"
                    },
                },
                messages: {
                    experienceSelection:{
//                        valueNotEquals:"請選擇相關項目"
                        regex:"請輸入有效資料"
                    },
                    occupationSelection:{
                        regex:"請輪入有效資料"
//                        valueNotEquals:"請選擇相關項目"
                    },
                    minHourlyWage:{
                        regex:"請輸入有效時數"
                    },
                    idealHourlyWage:{
                        regex:"請輸入有效時數"
                    }
                },
                errorPlacement: function(error, element) {
                    error.insertAfter(element);
                },
                submitHandler: function (form) {
                    $('#coachCVFormRow').animateCss('slideOutRight', function(){
                            $('#coachCVFormRow').hide();
                            $('#coachCVForm').hide();
                        }
                    );
                    return true
                }
            });

        });

    </script>


@endsection