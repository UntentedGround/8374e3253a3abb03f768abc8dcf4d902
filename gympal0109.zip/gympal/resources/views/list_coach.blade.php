@extends('masters.master')

@section('content')

<h1> Coach List</h1>
<table id="mytable">
	<thead><tr><th>username</th><th>activated</th><th>action</th></tr></thead>
	<tbody>
@foreach ($coachs as $coach)

        <tr><td> {!!$coach->username !!}</td><td> {!! ($coach->activated == 0) ? 'not activated':'activated' !!}</td>
	<td><a href=coach/{!! $coach->coach_id!!}>view</a> <a onclick="enable_coach({!! $coach->coach_id!!},'{!! $coach->username!!}',{!! $coach->activated!!})">enable/disable</a> <a onclick="delete_coach({!! $coach->coach_id!!},'{!! $coach->username!!}')">delete</a></td></tr>

@endforeach
        </tbody>
</table>

<script>
	$(document).ready(function(){
    $('#mytable').DataTable();


});

	function delete_coach(coach_id,username){

		if (confirm("are you sure deleting coach [" + username + "] ?") == true){
		
			window.location.href = "deletecoach";	
		}
	}

	function enable_coach(coach_id,username, activated){

		if (activated == 1)

		{
			alert('activated = 1');
			if (confirm("are you sure to disable coach [" + username + "] ?") == true){
		
				window.location.href = "disable_coach" ;
			}	
		}

		else

		{
			alert('activated = 1');

			if (confirm("are you sure to enable coach [" + username + "] ?") == true){
		
				window.location.href = "enable_coach" ;
			}
		}
		

		



	}


</script>
	

@endsection
