@extends('masters.master')

@section('content')
	
<h1> Coach Profile</h1>

<p>

<b>username : </b> {!!$coach->username !!} <br>

<b>password : </b> {!!$coach->password !!} <br>

<b>email : </b> {!!$coach->email !!} <br>

<b>address : </b> {!!$coach->address !!} <br>

<b>activated : </b> {!! ( $coach->activated == 0) ? 'not activated' : 'activated' !!} <br>

</p>
<p>

<b>available district</b>

<br><li id = "HK" class="district">Hong Kong</li><br>
<br><li id = "KN" class="district">Kowloon</li><br>
<br><li id = "NT" class="district">New terriotry</li><br>

</p>

<script>
	$(document).ready(function(){


@foreach ($all_districts as $district)
	@if ($district->region == 'HK')
			$('.district').filter($("#HK")).append('<br><input type="checkbox"> </input><b>{{!!$district->name !!}}</b><br>');
	@elseif ($district->region == 'KN')
			$('.district').filter($("#KN")).append('<br><input type="checkbox"> </input><b>{{!!$district->name !!}}</b><br>');
	@else 
			$('.district').filter($("#NT")).append('<br><input type="checkbox"> </input><b>{{!!$district->name !!}}</b><br>');

	@endif
@endforeach
    			


	});


</script> 
@endsection